#ifndef DEGREE_H
#define DEGREE_H


enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };

#endif
