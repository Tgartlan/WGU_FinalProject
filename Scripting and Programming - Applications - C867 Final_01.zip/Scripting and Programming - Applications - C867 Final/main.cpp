#include <iostream>
#include "roster.h"

int main() {
    const std::string studentData[] = {
        "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
        "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
        "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
        "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
        "A5,Tadhg,Gartlan,gartl4@wgu.edu,24,15,20,5,SOFTWARE"
    };

    Roster classRoster;

    
    for (const auto& data : studentData) {
        size_t pos = 0;
        std::string tokens[9];
        int index = 0;
        std::string temp = data;

        while ((pos = temp.find(',')) != std::string::npos) {
            tokens[index++] = temp.substr(0, pos);
            temp.erase(0, pos + 1);
        }
        tokens[index] = temp;

        classRoster.add(tokens[0], tokens[1], tokens[2], tokens[3], std::stoi(tokens[4]),
            std::stoi(tokens[5]), std::stoi(tokens[6]), std::stoi(tokens[7]),
            tokens[8] == "SECURITY" ? SECURITY : tokens[8] == "NETWORK" ? NETWORK : SOFTWARE);
    }

    std::cout << "Course: C867 | Language: C++ | Student ID: 012291129 | Name: Tadhg Gartlan\n\n";

    classRoster.printAll();
    classRoster.printInvalidEmails();

    for (int i = 0; i < 5; ++i) {
        classRoster.printAverageDaysInCourse("A" + std::to_string(i + 1));
    }

    std::cout << "DegreeProgram\n";

    classRoster.printByDegreeProgram(SOFTWARE);

    std::cout << "Removing A3" << std::endl;
    classRoster.remove("A3"); 
    classRoster.printAll();     

    std::cout << "Removing A3" << std::endl;
    classRoster.remove("A3");  

    return 0;
}
