#include "roster.h"
#include <iostream>


Roster::Roster() : lastIndex(-1) {}


Roster::~Roster() {
    for (int i = 0; i <= lastIndex; ++i) {
        delete classRosterArray[i];
    }
}


void Roster::add(std::string studentId, std::string firstName, std::string lastName,
    std::string emailAddress, int age, int daysInCourse1, int daysInCourse2,
    int daysInCourse3, DegreeProgram degreeProgram) {
    int days[3] = { daysInCourse1, daysInCourse2, daysInCourse3 };
    classRosterArray[++lastIndex] = new Student(studentId, firstName, lastName, emailAddress, age, days, degreeProgram);
}


void Roster::remove(std::string studentId) {
    for (int i = 0; i <= lastIndex; ++i) {
        if (classRosterArray[i]->getStudentId() == studentId) {
            delete classRosterArray[i];
            classRosterArray[i] = classRosterArray[lastIndex--];
            std::cout << "Student with ID " << studentId << " removed.\n";
            return;
        }
    }
    std::cout << "Error: Student with ID " << studentId << " not found.\n";
}


void Roster::printAll() {
    for (int i = 0; i <= lastIndex; ++i) {
        classRosterArray[i]->print();
    }
}


void Roster::printAverageDaysInCourse(std::string studentId) {
    for (int i = 0; i <= lastIndex; ++i) {
        if (classRosterArray[i]->getStudentId() == studentId) {
            int* days = classRosterArray[i]->getDaysInCourse();
            std::cout << "Average days for student " << studentId << ": "
                << (days[0] + days[1] + days[2]) / 3.0 << std::endl;
            return;
        }
    }
}

void Roster::printInvalidEmails() {
    for (int i = 0; i <= lastIndex; ++i) {
        std::string email = classRosterArray[i]->getEmailAddress();
        if (email.find('@') == std::string::npos || email.find('.') == std::string::npos || email.find(' ') != std::string::npos) {
            std::cout << "Invalid email: " << email << std::endl;
        }
    }
}


void Roster::printByDegreeProgram(DegreeProgram degreeProgram) {
    for (int i = 0; i <= lastIndex; ++i) {
        if (classRosterArray[i]->getDegreeProgram() == degreeProgram) {
            classRosterArray[i]->print();
        }
    }
}
